package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.security.auth.spi.Users;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.RegisterUserServices;
import com.cg.appl.services.RegisterUserServicesImpl;

@WebServlet("/register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
private RegisterUserServices services;
	public void init(ServletConfig config) throws ServletException {
	services = new RegisterUserServicesImpl();	
	}

	
	protected void ProcessRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String nextJsp = null;
		RequestDispatcher dispatch = null;
		User user = new User();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String password=request.getParameter("password");
		String gender = request.getParameter("gender");
		String skillset1 = request.getParameter("Java");
		String skillset2 = request.getParameter(".NET");
		String skillset3 = request.getParameter("Testing");
		String skillset4 = request.getParameter("MainFrame");
		String skillSet = skillset1 + " " +skillset2 + " "+skillset3 +" "+skillset4 ;
		String city = request.getParameter("City");
		user.setFirstName(fname);
		user.setLastName(lname);
		user.setPassword(password);
		user.setGender(gender);
		user.setSkillSet(skillSet);
		user.setCity(city);
		
		try {
			int update=services.storeUserDetails(user);
			if(update==1)
			{
				
				
				request.setAttribute("errMsg", "Successful Registration");
				nextJsp="success.jsp";
			}
			else
			{
				request.setAttribute("errMsg", "Registration Failed");
				nextJsp="error.jsp";
			}
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);
	}

}
