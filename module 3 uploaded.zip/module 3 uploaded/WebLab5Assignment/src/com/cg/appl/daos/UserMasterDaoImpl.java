package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.Bill;
import com.cg.appl.entities.Consumer;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.DbUtil;


public class UserMasterDaoImpl implements IUsermasterDao {

	private DbUtil util;
	
	public UserMasterDaoImpl(){
		
		util = new DbUtil();
	}
	

	
	@Override
	public Consumer getUserDetails(String consumerNumber) throws UserException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet res=null;
		String query="select consumer_num,consumer_name,address from consumers where consumer_num=?";
		Consumer consume=new Consumer();
		try {
			conn=util.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,consumerNumber);
			res=pstm.executeQuery();
			if(res.next())
			{
				consume.setNumber(res.getString("consumer_num"));
				consume.setName(res.getString("consumer_name"));
				consume.setAddress(res.getString("address"));
				
			}
			else
			{
				
				throw new UserException("User number is wrong");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("JDBC failed,e");
		}finally
		{
			
			try {
				if(res!=null)
				{
					res.close();
				}
				if(pstm!=null)
				{
					pstm.close();
				}
				if(conn!=null)
				{
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new UserException("JDBC failed,e");
			}

		}
		
		
		return consume;
	}

	@Override
	public int setUserDetails(Bill bill) throws UserException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int status=0;
		String query="INSERT INTO BILLDETAILS VALUES(SEQ_BILL_NUM.NEXTVAL,?,?,?,?,SYSDATE)";
		try {
			conn=util.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,bill.getConsumerNumber());
			pstm.setDouble(2, bill.getCurrReading());
			pstm.setDouble(3, bill.getUnitConsumed());
			pstm.setDouble(4,bill.getNetAmount());
			status=pstm.executeUpdate();
			
			
		} catch (UserException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("problem in insertion");
		}finally
		{
			try {
				if(pstm!=null)
				{
					pstm.close();
				}
				if(conn!=null)
				{
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
		return status;
	}

}
