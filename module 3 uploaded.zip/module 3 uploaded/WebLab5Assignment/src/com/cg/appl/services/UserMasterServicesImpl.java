package com.cg.appl.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.appl.daos.IUsermasterDao;
import com.cg.appl.daos.UserMasterDaoImpl;
import com.cg.appl.entities.Bill;
import com.cg.appl.entities.Consumer;
import com.cg.appl.exceptions.UserException;

public class UserMasterServicesImpl implements IUsermasterServices {
	
	IUsermasterDao userDao;
	
	public UserMasterServicesImpl()
	{
		userDao=new UserMasterDaoImpl();
		
	}

	@Override
	public Consumer getUserDetails(String consumerNumber) throws UserException {
		
		return userDao.getUserDetails(consumerNumber);
	}

	@Override
	public int setUserDetails(Bill bill) throws UserException {

		return userDao.setUserDetails(bill);
	}

	@Override
	public boolean isUserAuthenticated(String consumerNumber, String last,
			String current) throws UserException {
		Pattern number= Pattern.compile("^[1-9]{1}[0-9]{5}$");
		Matcher number1= number.matcher(consumerNumber);
		Pattern reading= Pattern.compile("^[0-9]{1,5}[.]{0,1}[0-9]{0,2}$");
		Matcher last1= reading.matcher(last);
		Pattern reading1= Pattern.compile("^[0-9]{1,5}[.]{0,1}[0-9]{0,2}$");
		Matcher current1= reading.matcher(current);
		double currentMonth=Double.parseDouble(current);
		double lastMonth=Double.parseDouble(last);
		
		if(number1.matches() && last1.matches() && current1.matches() && lastMonth>currentMonth)
		{
			return true;
		}
		else{
		
			return false;
		}
	}

	@Override
	public double calcUnits(double last, double current) {
		double units;
		units=last-current;
		return units;
	}

	@Override
	public double calcAmount(double units) {
		final int fixedCharge=100;
		double netAmount;
		netAmount=(units*1.15)+fixedCharge;
		return netAmount;
	}

}
