package com.cg.appl.util;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exceptions.UserException;





public class DbUtil {

	
	
	public static Connection obtainConnection() throws UserException{
		Connection  conn=null;	
	InitialContext context;
	try {
		context = new InitialContext();
		DataSource source = (DataSource) context.lookup("java:/OracleDS");
		conn = source.getConnection();
		
	} catch (NamingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new UserException("Problem in connection"+e);
	}
	return conn;
		
	}
	
	
}
