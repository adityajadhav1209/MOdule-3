package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JdbcUtil;

public class RegisterUserDaoImpl implements RegisterUserDao {
private JdbcUtil util;

public RegisterUserDaoImpl()
{
util = new JdbcUtil();	
}

@Override
public int storeUserDetails(User user) throws UserException {
	Connection connect = null;
	PreparedStatement stmt = null;
	int rec=0;
	String qry = "INSERT INTO REGISTEREDUSERS (FIRSTNAME,LASTNAME,PASSWORD,GENDER,SKILLSET,CITY) VALUES(?,?,?,?,?,?)";
	try {
		
		
		connect=util.getConnection();
		stmt=connect.prepareStatement(qry);
		stmt.setString(1,user.getFirstName());
		stmt.setString(2, user.getLastName());
		stmt.setString(3, user.getPassword());
		stmt.setString(4, user.getGender());
		stmt.setString(5, user.getSkillSet());
		stmt.setString(6, user.getCity());
		rec=stmt.executeUpdate();
		if(rec>0)
		{
			
			return rec;
		}
		else
		{
			throw new UserException("USer not registered");
		}
		
	} catch (SQLException e) {
		throw new UserException("Jdbc Failed",e);
	}
	finally
	{
	try {
		
		if(stmt!=null)
		{
			stmt.close();
		}if(connect!=null)
		{
			 connect.close();
			
		}
	} catch (SQLException e) {
		
		throw new UserException("Jdbc connection closing Failed");
	}
		
		
	}
	
	
	
}
	
	}

	

