package com.cg.appl.services;

import com.cg.appl.daos.RegisterUserDao;
import com.cg.appl.daos.RegisterUserDaoImpl;
import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public class RegisterUserServicesImpl implements RegisterUserServices {
 
	private RegisterUserDao dao;
	
	public RegisterUserServicesImpl() {
		dao = new RegisterUserDaoImpl();
	}

	@Override
	public int storeUserDetails(User user) throws UserException {
		
		return dao.storeUserDetails(user);
	}

}
