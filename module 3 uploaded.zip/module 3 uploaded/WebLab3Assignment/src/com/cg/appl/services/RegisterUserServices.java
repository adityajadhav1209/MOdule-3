package com.cg.appl.services;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public interface RegisterUserServices {
	int storeUserDetails(User user)throws UserException;
}
