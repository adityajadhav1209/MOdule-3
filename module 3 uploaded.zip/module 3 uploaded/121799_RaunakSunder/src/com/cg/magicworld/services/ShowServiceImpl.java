package com.cg.magicworld.services;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.magicworld.dao.IShowDao;
import com.cg.magicworld.dao.ShowDaoImpl;
import com.cg.magicworld.dto.Show;
import com.cg.magicworld.exception.ShowException;

public class ShowServiceImpl implements IShowService {

	IShowDao show;
	
	public ShowServiceImpl() throws ShowException {
		show=new ShowDaoImpl();
	}

	@Override
	public List<Show> showAll() throws ShowException {
		return show.showAll();
	}

	@Override
	public int updateSeats(int seats,String showName) throws ShowException {
		
		return show.updateSeats(seats,showName);
	}


	
}
