package com.cg.appl.tests;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;

public class TestUser {private static UserMasterServices services;

@BeforeClass
public static void initialize(){
	
	services = new UserMasterServicesImpl();
	
}


	@Test
	public void testGetUserDetails() {
	try {
		User user = services.getUserDetails("a");
		String actualPassword = "b";
		assertEquals(user.getPassword(),actualPassword);
		
		
	} catch (UserException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
