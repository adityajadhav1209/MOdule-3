package com.cg.appl.util;

/*import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;*/
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
private Properties props;
 private OracleDataSource dataSource;
	public JdbcUtil() {
		props=new Properties();
		//InputStream is = null;
		try {
			/* is = new FileInputStream("D:\\121638_module 3\\Web020LoginSimple\\src\\oracle.properties");
			props.load(is);
			dataSource = new OracleDataSource ();
			dataSource.setURL(props.getProperty("oracle.url"));
			dataSource.setUser(props.getProperty("oracle.uname"));
			dataSource.setPassword(props.getProperty("oracle.upass"));
			dataSource.setDriverType("oracle");*/
			
			dataSource = new OracleDataSource ();
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
			dataSource.setUser("labg104trg10");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
		}
		/*catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/ catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally{
			
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}*/
	
	}
	public Connection getConnection() throws SQLException{
		
		return dataSource.getConnection();
		
	}
	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}



}

