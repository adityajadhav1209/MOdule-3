create table usermaster(
USERNAME varchar2(15) PRIMARY KEY,
PASSWORD varchar2(15),
USERFNAME varchar2(40)
);






insert into usermaster(username,password,userfname) values('a','b','aaishapat');
insert into usermaster(username,password,userfname) values('bb','bc','baapshapat');

select * from usermaster;