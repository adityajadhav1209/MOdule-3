package com.cg.appl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private int visits=0;

	
	@Override
	public void destroy() {
	System.out.println("In destroy()");
		super.destroy();
	}


	@Override
	public void init() throws ServletException {
		
		super.init();
		System.out.println("In Init()");
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Method Type:"+request.getMethod());  //to find type of method
		System.out.println("message on console"+request.getServletPath()); //to find servlet path
		PrintWriter out=response.getWriter();
		out.write("welcome" +(++visits));
		response.setContentType("text/html");
		response.setIntHeader("Refresh", 5);
	}

}
