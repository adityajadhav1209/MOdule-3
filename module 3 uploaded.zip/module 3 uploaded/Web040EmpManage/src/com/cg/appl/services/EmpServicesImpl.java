package com.cg.appl.services;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.daos.EmpDaoImpl;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;

public class EmpServicesImpl implements EmpServices {
	
	private EmpDao dao;
	
	

	public EmpServicesImpl() {
		
		dao= new EmpDaoImpl();
		
	}

	@Override
	public Employee getEmpDetails(int empNo) throws EmpException {
		
		return dao.getEmpDetails(empNo);
	}

}
