select * from emp where empno=7533;
