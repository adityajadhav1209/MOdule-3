create table employeemanagement(emp_id number(10) primary key,emp_name varchar2(20),emp_qual varchar2(20),emp_sal number(10));

select * from employeemanagement;