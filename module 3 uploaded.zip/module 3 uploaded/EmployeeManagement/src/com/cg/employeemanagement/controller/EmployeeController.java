package com.cg.employeemanagement.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.services.EmployeeServiceImpl;
import com.cg.employeemanagement.services.IEmployeeService;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	IEmployeeService employeeService;
	
	public EmployeeController(){
		
		
		employeeService = new EmployeeServiceImpl();
	}
	

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);	
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request,response);
	}
	
	private void ProcessRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String path=request.getServletPath();
		System.out.println(path);
		if(path.equals("/empl.do")){
		RequestDispatcher res = request.getRequestDispatcher("addemployee.jsp");
		res.forward(request, response);
		}
		if(path.equals("/empadd.do"))
		{
			Employee emp = new Employee();
			String name=request.getParameter("jname");
			String qualification=request.getParameter("jqual");
			String salary=request.getParameter("jsal");
		    emp.setEmpName(name);
		    emp.setEmpQualification(qualification);
            emp.setEmpSalary(Double.parseDouble(salary));
            
            
            try {
				int empId=employeeService.addEmployee(emp);
				//System.out.println(empId);
				request.setAttribute("id", empId);
				RequestDispatcher req=request.getRequestDispatcher("welcome.jsp");
				req.forward(request, response);
				
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		else if(path.equals("/showall.do")){
			
			List<Employee> myList;
			try {
				myList = employeeService.showAll();
				//System.out.println(myList);
				request.setAttribute("data",myList);
				RequestDispatcher req=request.getRequestDispatcher("showall.jsp");
				req.forward(request, response);
				
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}else if(path.equals("/update.do")){
             System.out.println("update.....");	
             String empid=request.getParameter("id");
             System.out.println(empid);
             int id=Integer.parseInt(empid);
             Employee eData=employeeService.getEmployee(id);
             System.out.println(eData);
             request.setAttribute("empdata", eData);
             RequestDispatcher req=request.getRequestDispatcher("updateemployee.jsp");
				req.forward(request, response);
             
             
			
		}else if(path.equals("/delete.do")){
			  String empid=request.getParameter("id");
			  int eId=Integer.parseInt(empid);
			  
	        int deletedata=employeeService.deletedata(eId);
	        if(deletedata>=1){
	        	
	        	System.out.println("succesful deletion");
	        	
	        }else
	        {
	        	System.out.println("failed");
	        }
	        RequestDispatcher req=request.getRequestDispatcher("showall.do");
		    req.forward(request, response);
	        
	}
		else if(path.equals("/updatedata.do")){
			Employee emp = new Employee();
			String empid=request.getParameter("eID");
			 int eId=Integer.parseInt(empid);
            String name=request.getParameter("ename");
			String qualification=request.getParameter("equal");
			String salary=request.getParameter("esal");
			double esal=Double.parseDouble(salary);
			emp.setEmp_id(eId);
			emp.setEmpName(name);
		    emp.setEmpQualification(qualification);
            emp.setEmpSalary(esal);
			employeeService.updateemployee(emp);
			 RequestDispatcher req=request.getRequestDispatcher("showall.do");
		    req.forward(request, response);
		}

}
}
