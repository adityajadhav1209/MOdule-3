package com.cg.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		int empId=getEmployee();
		int msg=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="INSERT INTO EMPLOYEEMANAGEMENT VALUES(?,?,?,?)";
		try {
		
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,empId);
			pstm.setString(2,emp.getEmpName());
			pstm.setString(3, emp.getEmpQualification());
			pstm.setDouble(4, emp.getEmpSalary());
			
			int status=pstm.executeUpdate();
			if(status==1)
			{
				msg=empId;
			}
			
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in insertion");
		}finally{
			
			
			try {
				conn.close();
				pstm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return msg;
	}
	

	@Override
	public List<Employee> showAll() throws EmployeeException {
		int empId=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		List<Employee>myEmp=new ArrayList<>();
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement";
		try {
			
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
		    ResultSet res=pstm.executeQuery();
		    while(res.next())
		    {
		    	Employee e = new Employee();
		    	e.setEmp_id(res.getInt("emp_id"));
		    	e.setEmpName(res.getString("emp_name"));
		       e.setEmpQualification(res.getString("emp_qual"));
		       e.setEmpSalary(res.getDouble("emp_sal"));
		    	myEmp.add(e);
		    }
		}catch(EmployeeException | SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException("Problem in displaying");
			
		}
		
		return myEmp;
	}
	
	
	public int getEmployee() throws EmployeeException
	{   int empId=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="SELECT emp_id_seq.NEXTVAL FROM DUAL";
		try {
		
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
		    ResultSet res=pstm.executeQuery();
		    while(res.next())
		    {
		    	
		    	empId=res.getInt(1);
		    }
		}catch(EmployeeException | SQLException e){
			
			e.printStackTrace();
			throw new EmployeeException("Problem in generating emp id");
			
		}
		return empId;
	

}


	@Override
	public int deletedata(int emp_Id) {
		int del=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="DELETE from employeemanagement WHERE emp_id=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,emp_Id);
			del=pstm.executeUpdate();
			
		} catch (SQLException | EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return del;
	}


	@Override
	public Employee getEmployee(int id) {
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement where emp_id=?";
		Employee emp = new Employee();
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, id);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				
				emp.setEmp_id(res.getInt("emp_id"));
		    	emp.setEmpName(res.getString("emp_name"));
		       emp.setEmpQualification(res.getString("emp_qual"));
		       emp.setEmpSalary(res.getDouble("emp_sal"));
				
				
			}
			
			
		} catch (SQLException | EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}


	@Override
	public int updateemployee(Employee emp) {
		int upt=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="update employeemanagement set emp_name=?,emp_qual=?,emp_sal=? where emp_id=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,emp.getEmpName());
			pstm.setString(2,emp.getEmpQualification());
			pstm.setDouble(3,emp.getEmpSalary());
			pstm.setInt(4,emp.getEmp_id() );
			 upt=pstm.executeUpdate();
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return upt;
	}
}
