package com.cg.employeemanagement.dao;

import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public interface IEmployeeDao {


	public int addEmployee(Employee emp) throws EmployeeException;
	public List<Employee>showAll() throws EmployeeException;
   public int deletedata(int emp_Id);
    public Employee getEmployee(int id);
   public int updateemployee(Employee emp);
    
}
