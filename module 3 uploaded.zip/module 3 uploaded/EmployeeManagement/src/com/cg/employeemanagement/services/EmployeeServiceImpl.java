package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.IEmployeeDao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
IEmployeeDao empDao;
	
public EmployeeServiceImpl(){
	empDao=new EmployeeDaoImpl();
	
}

@Override
public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		
		return empDao.showAll();
	}

	@Override
	public int deletedata(int emp_Id) {
		
		return empDao.deletedata(emp_Id);
	}

	@Override
	public Employee getEmployee(int id) {
		
		return empDao.getEmployee(id);
	}

	@Override
	public int updateemployee(Employee emp) {
		
		return empDao.updateemployee(emp);
	}

}
