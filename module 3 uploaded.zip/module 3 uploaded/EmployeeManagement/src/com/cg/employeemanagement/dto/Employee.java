package com.cg.employeemanagement.dto;

public class Employee {

	private int emp_id;
	private String empName;
	private String empQualification;
	private double empSalary;
	
	public Employee() {
		super();
	}
	public Employee(int emp_id, String empName, String empQualification,
			double empSalary) {
		super();
		this.emp_id = emp_id;
		this.empName = empName;
		this.empQualification = empQualification;
		this.empSalary = empSalary;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpQualification() {
		return empQualification;
	}
	public void setEmpQualification(String empQualification) {
		this.empQualification = empQualification;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", empName=" + empName
				+ ", empQualification=" + empQualification + ", empSalary="
				+ empSalary + "]";
	}
	
	
	
}
