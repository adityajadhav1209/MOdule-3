package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.ITicketDao;
import com.cg.appl.daos.TicketDaoImpl;
import com.cg.appl.entities.Ticket;
import com.cg.appl.exceptions.TicketException;

public class TicketServiceImpl implements ITicketSevice {

	ITicketDao ticketDao;
	
	public TicketServiceImpl(){
		
		ticketDao= new TicketDaoImpl();
		
		
	}
	
	
	
	@Override
	public List<Ticket> showAll() throws TicketException {
		
		return ticketDao.showAll();
	}



	@Override
	public int updateSeats(String showName, int seats) throws TicketException {
		
		return ticketDao.updateSeats(showName, seats);
	}

}
