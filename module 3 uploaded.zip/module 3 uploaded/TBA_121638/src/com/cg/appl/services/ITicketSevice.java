package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Ticket;
import com.cg.appl.exceptions.TicketException;

public interface ITicketSevice {
	public List<Ticket>showAll() throws TicketException;
	int updateSeats(String showName,int seats) throws TicketException;
}
