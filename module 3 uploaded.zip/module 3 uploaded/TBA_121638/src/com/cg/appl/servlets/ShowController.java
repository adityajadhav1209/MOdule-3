package com.cg.appl.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.entities.Ticket;
import com.cg.appl.exceptions.TicketException;
import com.cg.appl.services.ITicketSevice;
import com.cg.appl.services.TicketServiceImpl;


@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message=null;
	ITicketSevice services;
	Ticket ticket;
	
	

	@Override
	public void init() throws ServletException {
		
		services = new TicketServiceImpl();
		ticket=new Ticket();
		
	}

	
	
	private void ProcessRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException, TicketException {
	
		String command=request.getServletPath();
		System.out.println(command);
		
		List<Ticket>myList=null;
		switch(command){
		
		case "/showdetails.do":{
			
		     	myList=new ArrayList<>();
		    
				myList=services.showAll();
				request.setAttribute("data",myList);
				nextJsp="/showDetails.jsp";
				break; }
			
		
		
		
		case "/booknow.do":
		{
			
			String name=request.getParameter("name");
        	String price=request.getParameter("price");
        	String seats=request.getParameter("seats");
        	request.setAttribute("showName", name);
        	request.setAttribute("showPrice", price);
        	request.setAttribute("showSeats", seats);
        	nextJsp="bookNow.jsp";
        	break;	
			
		}
		
		
		case "/book.do":{
			String showName=request.getParameter("sname");
			String Pticket=request.getParameter("pticket");
			double price=Double.parseDouble(Pticket);
			String cname=request.getParameter("cname");
			String mnumber=request.getParameter("number");
			String seatStr=request.getParameter("seats");
			int seat=Integer.parseInt(seatStr);
			String avSeats = request.getParameter("seatavailble");
			double totalPrice=seat*price;
			int update = services.updateSeats(showName, seat);
			if(update==1){
			
		        request.setAttribute("showName",showName);
		        request.setAttribute("totalPrice",totalPrice);
		        request.setAttribute("name",cname);
		        request.setAttribute("mobile",mnumber);
		        request.setAttribute("bookSeats",seat);
	        	nextJsp="/success.jsp";
	        	}else
	        	{
	        		
	        		nextJsp="/error.jsp";
	        	}
				
			break;	
				
			}
			
		}
	 dispatch=request.getRequestDispatcher(nextJsp);
		 dispatch.forward(request,response);
	
	
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		try {
			ProcessRequest(request,response);
		} catch (TicketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			ProcessRequest(request,response);
		} catch (TicketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
