package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.appl.entities.Ticket;
import com.cg.appl.exceptions.TicketException;
import com.cg.appl.util.DbUtil;


public class TicketDaoImpl implements ITicketDao {

	private DbUtil util;
	
	public TicketDaoImpl(){
		
		util=new DbUtil();
		
	}
	
	
	@Override
	public List<Ticket> showAll() throws TicketException {
		
		Connection conn=null;
        PreparedStatement pstm=null;
        List<Ticket>myList=new ArrayList<>();
        ResultSet res=null;
        String query="SELECT SHOWID,SHOWNAME,LOCATION,SHOWDATE,AVSEATS,PRICETICKET FROM SHOWDETAILS";
        
        try {
			conn=util.obtainConnection();
			pstm=conn.prepareStatement(query);
			res=pstm.executeQuery();
			while(res.next()){
			Ticket ticket = new Ticket();
			
			ticket.setShowId(res.getString("SHOWID"));
			ticket.setShowName(res.getString("SHOWNAME"));
			ticket.setLocation(res.getString("LOCATION"));
			ticket.setShowDate(res.getDate("SHOWDATE"));
			ticket.setPriceTicket(res.getDouble("PRICETICKET"));
			ticket.setAvailabeSeats(res.getInt("AVSEATS"));
			
			myList.add(ticket);
				
			}
			
			
		} catch (TicketException | SQLException e) {
			// TODO Auto-generated catch block
			
			throw new TicketException("List failed to display");
		}finally
		{
			try {
				if(res!=null){
					
					res.close();
				}if(pstm!=null){
					pstm.close();
				}if(conn!=null){
					
					conn.close();
				}
			} catch (SQLException e) {
				throw new TicketException("Connection was not established",e);
			}
			
		}
 	
		return myList;
	}


	@Override
	public int updateSeats(String showName, int seats) throws TicketException {
		int upt=0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query="UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWNAME=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,seats);
			pstm.setString(2, showName);
			upt=pstm.executeUpdate();
			
		} catch (TicketException | SQLException e) {
			throw new TicketException("Problem in  data");
			
		}
		finally{
			
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				
				throw new TicketException("Connection was not established",e);
			}
			
		}
		
		
		return upt;
	}

}
