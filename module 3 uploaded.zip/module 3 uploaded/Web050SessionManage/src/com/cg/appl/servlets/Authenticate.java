package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;

	
	
	public void init() throws ServletException {
		
		try {
			services = new UserMasterServicesImpl();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	
	}
	
	
	
protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		String userName=request.getParameter("userNm");
		String password=request.getParameter("password");
		RequestDispatcher dispatch = null;
		String nextJsp=null;
		String message = null;
		try {
			boolean isAuthenticated = services.isUserAuthenticated(userName, password);
			
			if(isAuthenticated)
			{
				//System.out.println("yes");
				
				/*dispatch = request.getRequestDispatcher("/MainMenu.jsp");
				dispatch.forward(request, response);*/
				 nextJsp = "/MainMenu.jsp";
				
			}else
			{
				//System.out.println("no");
				/*dispatch = request.getRequestDispatcher("/Login.jsp");
				dispatch.forward(request, response);*/
				
				message = "Wrong Credentials. Enter Again";
				request.setAttribute("errorMsg", message);
				nextJsp = "/Login.jsp";
				
				
			}
		} catch (UserException e) {
			
			//e.printStackTrace();
			/*dispatch = request.getRequestDispatcher("/Error.jsp");
			dispatch.forward(request, response);*/
			message = "UserName does not exist.";
			request.setAttribute("errMsg", message);
			nextJsp = "/Error.jsp";
			
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
		
}

	public void destroy() {
		
	}

	
	

}
