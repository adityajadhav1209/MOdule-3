package com.cg.appl.servlets;



import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserMasterServices services;
    private RequestDispatcher dispatch;
    private String nextJsp;
    String message = null;
    ServletContext ctx = null;
	
	public void init() throws ServletException {
		ctx = super.getServletContext();	
		services =  (UserMasterServices)ctx.getAttribute("services");	
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
	String command = request.getServletPath();
	//System.out.println("Command"+command);
	ctx.log("Command:" +command);
	switch(command){
	
	case "/Login.do":{
		
		nextJsp = "/Login.jsp";
		
		break;
	}
	case "/authenticate.do":{
		String userName=request.getParameter("userNm");
		String password=request.getParameter("password");
		try {
			boolean isAuthenticated = services.isUserAuthenticated(userName,password);
			
			if(isAuthenticated)
			{
				// start a session
				User user = services.getUserDetails(userName);
				
				HttpSession session = request.getSession(true); //session created
				System.out.println(session.getId());
				session.setAttribute("user", user);
				
				 nextJsp = "/MainMenu.jsp";
				
			}else
			{
				//System.out.println("no");
				/*dispatch = request.getRequestDispatcher("/Login.jsp");
				dispatch.forward(request, response);*/
				
				message = "Wrong Credentials. Enter Again";
				request.setAttribute("errMsg", message);
				nextJsp = "/Login.jsp";
				
				
			}
		} catch (UserException e) {
			
			//e.printStackTrace();
			/*dispatch = request.getRequestDispatcher("/Error.jsp");
			dispatch.forward(request, response);*/
			message = "UserName does not exist.";
			request.setAttribute("errMsg", message);
			ctx.log(e.getMessage());
			nextJsp = "/Error.jsp";
			
		}
		break;
	}// end of authenticate.do case
	
	case "/logout.do" :{
		
		HttpSession session = request.getSession(false);
		session.invalidate();    //Destroys session.
		
		nextJsp = "/Login.jsp";
		
		
	}

	
	}
	dispatch = request.getRequestDispatcher(nextJsp);
	dispatch.forward(request, response);
	
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	processRequest(request,response);
	
	}

	public void destroy() {
		services = null;
	}

}
