package com.cg.appl.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JdbcUtil;
import com.cg.appl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao {
// private JdbcUtil util;
	private JndiUtil util;
 public UserMasterDaoImpl() throws UserException{
	 
	// util= new JdbcUtil();
	 util = new JndiUtil();
	 
 }
	@Override
	public User getUserDetails(String userName) throws UserException {
		
		Connection connect = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		String qry = "SELECT PASSWORD,USERFNAME FROM USERMASTER WHERE USERNAME=?";
		
		try {
			 connect=util.getConnection();
			 stmt=connect.prepareStatement(qry);
			 stmt.setString(1, userName);
			rs = stmt.executeQuery();
			 if(rs.next())
			 {
				
				String password = rs.getString("PASSWORD");
				String fullName = rs.getString("USERFNAME");
				
				 User user = new User(userName,password,fullName);
				 return user;
				 
			 }else{
				 throw new UserException("Username wrong");
			 }
			 
		} catch (SQLException e) {
			
			throw new UserException("Jdbc Failed",e);
		}finally
		{
		try {
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null)
			{
				stmt.close();
			}if(connect!=null)
			{
				 connect.close();
				
			}
		} catch (SQLException e) {
			
			throw new UserException("Jdbc connection closing Failed");
		}
			
			
		}
		
	}

}
