package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exceptions.UserException;

public class JndiUtil {
 private DataSource dataSource;
	public JndiUtil() throws UserException {
		try {
			Context ctx = new InitialContext();  // get reference to remote JNDI
			dataSource = (DataSource) ctx.lookup("java:/NewOracleDS");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("Failed to get JNDI context",e);
		}
			
	}

public Connection getConnection() throws SQLException{
		
		return dataSource.getConnection();
		
	}
	


}



